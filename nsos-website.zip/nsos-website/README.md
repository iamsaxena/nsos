# Namahmi School of Skills — website

A single-page, fully self-contained static site. Every image, style and script is
embedded in `index.html`, so there is **no build step** — any static host serves it as-is.

```
index.html      → the entire website
og-image.png    → link-preview image (referenced by the social meta tags)
sitemap.xml     → SEO sitemap
robots.txt      → crawler rules (points to the sitemap)
vercel.json     → optional Vercel headers/caching (safe to keep or delete)
CNAME           → GitHub Pages custom-domain file (see the note below)
```

---

## Important: one apex domain, one host

`nsos.live` (the apex/root) can point to **only one** provider at a time. Pick the
one you want as primary. The other can still run on its free default URL
(`*.github.io` or `*.vercel.app`) or on a subdomain such as `app.nsos.live`.

- **Primary = GitHub Pages** → keep the `CNAME` file.
- **Primary = Vercel** → **delete the `CNAME` file** (otherwise GitHub Pages will try to claim the domain).

---

## Option A — GitHub Pages

1. Create a new repository (e.g. `nsos-website`) at github.com → New repository.
2. Upload everything in this folder (drag the files into the repo's "Add file → Upload files", or use git):
   ```bash
   git init
   git add .
   git commit -m "Initial site"
   git branch -M main
   git remote add origin https://github.com/<your-username>/nsos-website.git
   git push -u origin main
   ```
3. In the repo: **Settings → Pages**.
4. Under **Build and deployment → Source**, choose **Deploy from a branch**.
5. Branch = `main`, folder = `/ (root)` → **Save**.
6. Wait ~1 minute. Your site is live at `https://<your-username>.github.io/nsos-website/`.
7. **Custom domain:** in Settings → Pages → Custom domain, enter `nsos.live` → Save,
   then tick **Enforce HTTPS** (appears after DNS propagates). The included `CNAME`
   file already sets this for you.

### DNS for GitHub Pages (set these at your domain registrar)
For the apex `nsos.live` — four **A** records:
```
A   @   185.199.108.153
A   @   185.199.109.153
A   @   185.199.110.153
A   @   185.199.111.153
```
(Optional IPv6 — four **AAAA** records:)
```
AAAA  @  2606:50c0:8000::153
AAAA  @  2606:50c0:8001::153
AAAA  @  2606:50c0:8002::153
AAAA  @  2606:50c0:8003::153
```
For `www`:
```
CNAME  www  <your-username>.github.io
```

---

## Option B — Vercel (recommended for easiest updates)

1. Push the repo to GitHub (steps 1–2 above) — or use the Vercel CLI on the folder.
2. Go to vercel.com → **Add New… → Project** → **Import** your GitHub repo.
3. Framework preset: **Other** (it's plain static). Leave build command empty,
   output directory = root. Click **Deploy**.
4. Live in seconds at `https://<project>.vercel.app`.
5. **Custom domain:** Project → **Settings → Domains** → add `nsos.live` (and `www.nsos.live`).
   Vercel shows the exact records to add — use those if they differ from below.

### DNS for Vercel
```
A      @     76.76.21.21
CNAME  www   cname.vercel-dns.com
```
> Vercel's dashboard is the source of truth — if it shows different values, follow the dashboard.

CLI alternative (no GitHub needed):
```bash
npm i -g vercel
cd nsos-website
vercel           # follow prompts → preview URL
vercel --prod    # promote to production
```

---

## After it's live — checklist

- Visit the site over **https://** and confirm the padlock.
- Open a WhatsApp/LinkedIn/X message, paste the URL, and confirm the preview card
  shows the logo (`og-image.png`). Previews are cached; if you update the image later,
  re-scrape via the platform's debugger (e.g. LinkedIn Post Inspector, X Card Validator).
- Scan the Instagram QR on the page to confirm it opens `instagram.com/nsos.live`.
- Tap the phone/email links on a phone to confirm they dial/compose correctly.

## Notes

- **Query form:** submitting opens the visitor's email app pre-filled to
  `help@nsos.live` (no server needed). To receive submissions **directly in your inbox**
  without opening a mail app, wire a free no-backend service such as Web3Forms — it
  needs one access key; ask and it can be added to `index.html`.
- **OG image URL** is absolute (`https://nsos.live/og-image.png`). If your primary
  domain ends up different, update the `og:image` / `twitter:image` URLs in
  `index.html` to match.
- **Editing content:** everything lives in `index.html`. Re-deploy by pushing the
  change (GitHub Pages/Vercel redeploy automatically on push).
